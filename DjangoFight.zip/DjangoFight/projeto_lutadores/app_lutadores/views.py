from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import * # Importa todos os seus modelos, incluindo Lutador, Golpe, Usuario, Amizade, Inimizade
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User # <-- Importe o modelo User padrão do Django
from django.db.models import Prefetch

def home_view(request):
    """
    Exibe a lista de lutadores e provê botões para adicionar e remover.
    """
    lutadores = Lutador.objects.all()
    contexto = {'lutadores': lutadores}
    return render(request, 'home.html', contexto)

@require_POST
def remover_lutador(request, id_lutador):
    """
    Remove o lutador de acordo com o ID enviado pelo form.
    """
    lutador = get_object_or_404(Lutador, pk=id_lutador)
    lutador.delete()
    messages.success(request, 'Lutador removido com sucesso!') # Adicionando mensagem de sucesso
    return redirect('home')

@login_required
def criar_lutador_view(request):
    lutadores_existentes = Lutador.objects.all() # Carregar para as checkboxes de Amizades/Inimizades

    # --- OBTÉM A INSTÂNCIA DO SEU MODELO USUARIO CUSTOMIZADO ---
    # ESSA LÓGICA É CRÍTICA PARA TODOS OS LUGARES ONDE VOCÊ PRECISA LIGAR ALGO AO USUÁRIO LOGADO.
    try:
        # Pega a instância do seu modelo Usuario que tem o mesmo 'nome' do username do User logado.
        usuario_custom = Usuario.objects.get(nome=request.user.username)
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado no sistema. Por favor, contate o administrador.')
        return redirect('home') # Redireciona para home ou para uma página de erro.
    except Exception as e: # Captura outros erros inesperados
        messages.error(request, f'Erro inesperado ao buscar perfil de usuário: {e}.')
        return redirect('home')
    # --- FIM DA OBTENÇÃO DA INSTÂNCIA ---

    if request.method == 'POST':
        # Verifica limite somente após POST
        # Use usuario_custom para o filtro do limite
        if Lutador.objects.filter(usuario=usuario_custom).count() >= 2:
            messages.error(request, "Você já atingiu o limite de 2 lutadores.")
            return render(request, 'criar_lutador.html', {
                'lutadores': lutadores_existentes # Mantém os lutadores para re-renderizar o formulário
            })

        nome = request.POST['nome']
        idade = request.POST.get('idade') or None
        profissao = request.POST.get('profissao') or ''
        historia = request.POST.get('historia') or ''

        try:
            novo = Lutador.objects.create(
                nome=nome,
                idade=idade,
                profissao=profissao,
                historia=historia,
                usuario=usuario_custom # ATRIBUIR A INSTÂNCIA DO SEU USUARIO CUSTOMIZADO AQUI
            )

            # Lógica para Amizades (Many-to-Many)
            amizades_ids = request.POST.getlist('amizades')
            for amigo_id in amizades_ids:
                if amigo_id and amigo_id.isdigit(): # Garante que o ID é numérico
                    amigo_lutador = get_object_or_404(Lutador, id_lutador=int(amigo_id))
                    Amizade.objects.create(lutador=novo, amigo=amigo_lutador) # Passe o objeto Lutador

            # Lógica para Inimizades (Many-to-Many)
            inimizades_ids = request.POST.getlist('inimizades')
            for inimigo_id in inimizades_ids:
                if inimigo_id and inimigo_id.isdigit(): # Garante que o ID é numérico
                    inimigo_lutador = get_object_or_404(Lutador, id_lutador=int(inimigo_id))
                    Inimizade.objects.create(lutador=novo, inimigo=inimigo_lutador) # Passe o objeto Lutador

            messages.success(request, 'Lutador criado com sucesso!')
            return redirect('home')

        except Exception as e:
            messages.error(request, f'Erro ao criar lutador: {e}')
            return render(request, 'criar_lutador.html', {
                'lutadores': lutadores_existentes,
            })

    contexto = {'lutadores': lutadores_existentes}
    return render(request, 'criar_lutador.html', contexto)


def ver_lutador_view(request, id_lutador):
    lutador = get_object_or_404(Lutador, id_lutador=id_lutador)
    lutadores = Lutador.objects.exclude(id_lutador=lutador.id_lutador)  # todos menos o atual

    # Amizades e Inimizades são ManyToManyFields, você pode acessá-las diretamente
    # Se você está usando os modelos Amizade e Inimizade como intermediários,
    # os IDs já são obtidos como você fez.
    amizades_ids = list(Amizade.objects.filter(lutador=lutador).values_list('amigo__id_lutador', flat=True))
    inimizades_ids = list(Inimizade.objects.filter(lutador=lutador).values_list('inimigo__id_lutador', flat=True))

    return render(request, 'ver_lutador.html', {
        'lutador': lutador,
        'lutadores': lutadores,
        'amizades_ids': amizades_ids,
        'inimizades_ids': inimizades_ids,
    })


@require_POST
@login_required # Adicionar login_required para segurança
def editar_lutador_view(request, id_lutador):
    lutador = get_object_or_404(Lutador, id_lutador=id_lutador)

    # OBTÉM A INSTÂNCIA DO SEU MODELO USUARIO CUSTOMIZADO (para verificação de posse)
    try:
        usuario_custom = Usuario.objects.get(nome=request.user.username)
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado.')
        return redirect('home')
    except Exception as e:
        messages.error(request, f'Erro inesperado ao buscar perfil: {e}.')
        return redirect('home')

    # VERIFICA SE O USUÁRIO LOGADO É O DONO DO LUTADOR ANTES DE EDITAR
    if lutador.usuario != usuario_custom:
        messages.error(request, 'Você não tem permissão para editar este lutador.')
        return redirect('ver_lutador', id_lutador=id_lutador)


    lutador.nome = request.POST.get('nome', lutador.nome)
    idade = request.POST.get('idade')
    lutador.idade = int(idade) if idade else None
    lutador.profissao = request.POST.get('profissao', lutador.profissao)
    lutador.historia = request.POST.get('historia', lutador.historia)
    lutador.save()
    messages.success(request, 'Lutador atualizado com sucesso!') # Mensagem de sucesso

    # Atualizar amizades
    # Limpa as amizades existentes e adiciona as novas
    Amizade.objects.filter(lutador=lutador).delete() # Remove todas as amizades antigas
    amizades_ids = request.POST.getlist('amizades')
    for amigo_id in amizades_ids:
        if amigo_id and amigo_id.isdigit():
            amigo_lutador = get_object_or_404(Lutador, id_lutador=int(amigo_id))
            Amizade.objects.create(lutador=lutador, amigo=amigo_lutador)

    # Atualizar inimizades
    # Limpa as inimizades existentes e adiciona as novas
    Inimizade.objects.filter(lutador=lutador).delete() # Remove todas as inimizades antigas
    inimizades_ids = request.POST.getlist('inimizades')
    for inimigo_id in inimizades_ids:
        if inimigo_id and inimigo_id.isdigit():
            inimigo_lutador = get_object_or_404(Lutador, id_lutador=int(inimigo_id))
            Inimizade.objects.create(lutador=lutador, inimigo=inimigo_lutador)

    return redirect('ver_lutador', id_lutador=lutador.id_lutador)

@login_required # Adicionar login_required
def adicionar_golpe_view(request):
    # --- OBTÉM A INSTÂNCIA DO SEU MODELO USUARIO CUSTOMIZADO ---
    try:
        usuario_custom = Usuario.objects.get(nome=request.user.username)
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado no sistema. Por favor, contate o administrador.')
        return redirect('home')
    except Exception as e:
        messages.error(request, f'Erro inesperado ao buscar perfil de usuário: {e}.')
        return redirect('home')
    # --- FIM DA OBTENÇÃO DA INSTÂNCIA ---

    lutadores = Lutador.objects.filter(usuario=usuario_custom) # Filtra lutadores APENAS do usuário logado

    if request.method == 'POST':
        lutador_id = request.POST.get('lutador_id')
        nome = request.POST.get('nome')
        tipo = request.POST.get('tipo')
        descricao = request.POST.get('descricao')
        forca = request.POST.get('forca')

        # Certifique-se de que o lutador pertence ao usuário logado
        lutador = get_object_or_404(Lutador, id_lutador=lutador_id, usuario=usuario_custom)

        try:
            Golpe.objects.create(
                lutador=lutador,
                nome=nome,
                tipo=tipo,
                descricao=descricao,
                forca=forca,
                usuario=usuario_custom # ATRIBUIR A INSTÂNCIA DO SEU USUARIO CUSTOMIZADO AQUI
            )
            messages.success(request, 'Golpe adicionado com sucesso!')
            return redirect('lista_golpes') # Redireciona para a lista de golpes
        except Exception as e:
            messages.error(request, f'Erro ao adicionar golpe: {e}')
            return render(request, 'adicionar_golpe.html', {'lutadores': lutadores})

    return render(request, 'adicionar_golpe.html', {'lutadores': lutadores})


def lista_golpes_view(request):
    # OPCIONAL: Se quiser mostrar apenas golpes do usuário logado, adicione login_required e filtre.
    # @login_required
    # try:
    #     usuario_custom = Usuario.objects.get(nome=request.user.username)
    # except Usuario.DoesNotExist:
    #     messages.error(request, 'Perfil de usuário não encontrado.')
    #     return redirect('home')
    # golpes = Golpe.objects.select_related('lutador').filter(usuario=usuario_custom)

    golpes = Golpe.objects.select_related('lutador').all()
    return render(request, 'lista_golpes.html', {'golpes': golpes})

def ver_golpe_view(request, id_golpe):
    golpe = get_object_or_404(Golpe, id_golpe=id_golpe)
    # OPÇÃO: Para exibir apenas lutadores do usuário logado na edição de golpe
    # if request.user.is_authenticated:
    #     try:
    #         usuario_custom = Usuario.objects.get(nome=request.user.username)
    #         lutadores = Lutador.objects.filter(usuario=usuario_custom)
    #     except Usuario.DoesNotExist:
    #         lutadores = Lutador.objects.none() # Nenhum lutador se o perfil não existe
    # else:
    #     lutadores = Lutador.objects.all() # Ou redirecione para login
    lutadores = Lutador.objects.all() # Mantendo como estava, mas ciente da opção acima.

    return render(request, 'ver_golpe.html', {'golpe': golpe, 'lutadores': lutadores})


@require_POST
@login_required # Adicionar login_required para segurança
def editar_golpe_view(request, id_golpe):
    golpe = get_object_or_404(Golpe, id_golpe=id_golpe)

    # OBTÉM A INSTÂNCIA DO SEU MODELO USUARIO CUSTOMIZADO (para verificação de posse)
    try:
        usuario_custom = Usuario.objects.get(nome=request.user.username)
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado.')
        return redirect('home')
    except Exception as e:
        messages.error(request, f'Erro inesperado ao buscar perfil: {e}.')
        return redirect('home')

    # VERIFICA SE O USUÁRIO LOGADO É O DONO DO GOLPE ANTES DE EDITAR
    if golpe.usuario != usuario_custom:
        messages.error(request, 'Você não tem permissão para editar este golpe.')
        return redirect('ver_golpe', id_golpe=id_golpe)

    golpe.nome = request.POST.get('nome', golpe.nome)
    golpe.descricao = request.POST.get('descricao', golpe.descricao)
    golpe.forca = request.POST.get('forca', golpe.forca)
    golpe.tipo = request.POST.get('tipo', golpe.tipo)

    lutador_id = request.POST.get('lutador')
    if lutador_id:
        # Certifique-se de que o lutador selecionado também pertence ao usuário logado
        golpe.lutador = get_object_or_404(Lutador, id_lutador=int(lutador_id), usuario=usuario_custom)
    golpe.save()
    messages.success(request, 'Golpe atualizado com sucesso!') # Mensagem de sucesso

    return redirect('ver_golpe', id_golpe=golpe.id_golpe)

@require_POST
@login_required # Adicionar login_required para segurança
def remover_golpe_view(request, id_golpe):
    golpe = get_object_or_404(Golpe, id_golpe=id_golpe)

    # OBTÉM A INSTÂNCIA DO SEU MODELO USUARIO CUSTOMIZADO
    try:
        usuario_custom = Usuario.objects.get(nome=request.user.username)
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado.')
        return redirect('home')
    except Exception as e:
        messages.error(request, f'Erro inesperado ao buscar perfil: {e}.')
        return redirect('home')

    # VERIFICA SE O USUÁRIO LOGADO É O DONO DO GOLPE ANTES DE REMOVER
    if golpe.usuario != usuario_custom:
        messages.error(request, 'Você não tem permissão para remover este golpe.')
        return redirect('lista_golpes') # Ou para a página do golpe específico

    golpe.delete()
    messages.success(request, 'Golpe removido com sucesso!') # Mensagem de sucesso
    return redirect('lista_golpes')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('nome')
        password = request.POST.get('senha')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, f'Bem-vindo, {user.username}!') # Mensagem de boas-vindas
            return redirect('home')
        else:
            messages.error(request, 'Nome de usuário ou senha inválidos.')
    return render(request, 'login.html')

@login_required
def simulador_combate_view(request):
    """
    Renderiza a página do simulador de combate, passando dados de lutadores e golpes.
    """
    try:
        # Pega o usuário logado. Se 'Usuario' é seu modelo customizado, ajuste conforme necessário.
        # Se 'request.user' já é sua instância de Usuario, pode ser mais simples.
        # Exemplo: Se request.user já é um objeto Usuario:
        # usuario_custom = request.user
        # Se você usa o modelo User do Django e tem uma relação OneToOne com Usuario:
        usuario_custom = Usuario.objects.get(nome=request.user.username)
        
    except Usuario.DoesNotExist:
        messages.error(request, 'Seu perfil de usuário (Usuario) não foi encontrado no sistema. Por favor, crie um ou entre em contato com o suporte.')
        return redirect('home') # Ou para uma página apropriada
    except Exception as e:
        messages.error(request, f'Erro inesperado ao buscar perfil do usuário: {e}.')
        return redirect('home')

    # Usa prefetch_related para buscar lutadores e seus golpes em uma única consulta otimizada.
    # O 'related_name' 'golpes' deve ser o nome que você definiu no ForeignKey em Golpe para Lutador.
    # O to_attr='golpes_list' cria um atributo 'golpes_list' em cada objeto Lutador.
    lutadores = Lutador.objects.filter(usuario=usuario_custom).prefetch_related(
        Prefetch(
            'golpes', # Este é o related_name do ForeignKey de Golpe para Lutador
            queryset=Golpe.objects.all(), # Seleciona todos os golpes relacionados
            to_attr='golpes_list' # Os golpes serão armazenados neste atributo em cada Lutador
        )
    )

    # Prepara os dados para serem serializados para JSON no template.
    lutadores_data = []
    for lutador in lutadores:
        golpes_para_json = []
        # Itera sobre 'golpes_list', que agora contém objetos Golpe completos.
        for golpe in lutador.golpes_list:
            golpes_para_json.append({
                'id': golpe.id_golpe,  # Acesse os atributos diretamente com '.'
                'nome': golpe.nome,
                'tipo': golpe.tipo,
                'descricao': golpe.descricao,
                'forca': golpe.forca,
            })

        lutadores_data.append({
            'id': lutador.id_lutador,
            'nome': lutador.nome,
            'vida_inicial': 100, # Você pode buscar isso do lutador se tiver um campo 'vida_inicial'
            'sp_inicial': 0,    # Você pode buscar isso do lutador se tiver um campo 'sp_inicial'
            'golpes_data': golpes_para_json # Lista de golpes formatada para JS
        })

    context = {
        'lutadores': lutadores_data,
    }
    return render(request, 'simulador_combate.html', context)

def logout_view(request):
    logout(request) # Usar a função logout do Django é o recomendado
    messages.info(request, 'Você foi desconectado.') # Mensagem de info
    return redirect('login')

def exemplo_view(request):
    return HttpResponse("Essa é a view de exemplo") # retorna uma resposta em html